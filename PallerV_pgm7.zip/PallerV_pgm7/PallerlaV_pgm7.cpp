/*Vishi Pallerla, CS 2010, 3:30p - 4:20p
* Program 6, PallerlaV_pgm7.cpp, 12/12/21
* 
* Purpose: Take a file containing the names and average rebounds of basketball players during the 2020-21 season.
* Sort the data by the alphabetical oreder of the player names, then search for the average reounds of a given player
* using a binary search method.
* 
* Input: Take in a file called "centers_rebs_20_21.txt" that contains the data. Later, take in player names entered
* by the user.
* 
* Processing: Declare two parallel arrays in the main fucntion, one for the names and one for the average rebounds of
* the player, then store the data in them. A print function prints out the data. Then a function sorts the names array
* in alphabetical order of the names, with the average rebounds array changing accordingly. The data is printed again
* after it's been sorted. In the main function, write a loop to ask the user for a player name. A search funciton takes
* in the name and finds the index of it in the array using a binary search. It then returns the matching average rebounds
* that player, and it is printed out in the main funciton. This continues until the user enters "-1".
* 
* Output: The data is printed out once at the beginning, than again after it's sorted. The matching average rebounds of
* players are printed based on what names the user enters.
*/

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

//Prints out the name and average rebound arrays
void print(string names[], double avgRebs[]) {
	cout << left << setw(20) << "Name";
	cout << "Average Rebounds" << endl;
	cout << "------------------------------------" << endl;
	for (int i = 0; i < 50; ++i) {
		cout << left << setw(20) << names[i] << "   ";
		cout << setw(6) << avgRebs[i] << endl;
	}
}

//Sorts the name array using an insertion sort, then changes the average rebound array so that the array are still parallel.
void nameSort(string names[], double avgRebs[], int numE) {
	string tempName;
	double tempAvgRebs;
	int j = 0;

	for (int i = 0; i < numE; ++i) {
		j = i;
		while (j > 0 && names[j] < names[j - 1]) {
			//swaps elements in name array
			tempName = names[j];
			names[j] = names[j - 1];
			names[j - 1] = tempName;
			//swaps elements in average rebound array
			tempAvgRebs = avgRebs[j];
			avgRebs[j] = avgRebs[j - 1];
			avgRebs[j -1] = tempAvgRebs;

			--j;
		}
	}
}

//Does a binary search to find a given name, then returns the corresponding average rebounds of that player.
double search(string names[], double avgRebs[], string name, int numE) {
	//initilazies values used in searching
	int low = 0;
	int high = numE - 1;
	int mid = 0;
	while (low <= high) {
		mid = (low + high) / 2;
		//if the name is lower than the middle name, then high is assigned mid - 1
		if (name < names[mid]) {
			high = mid - 1;
		}
		//if the name is greater then the middle name, then low is asssigned mid + 1
		else if (name > names[mid]) {
			low = mid + 1;
		}
		//returns the average rebounds of the player if the name is found
		else {
			return avgRebs[mid];
		}
	}
	//if the name is never found
	return -1.0;
}

int main() {
	//variable declaration
	//input file
	ifstream inFile;
	//arrays, names and average rebounds
	string names[50];
	double avgRebs[50];
	//for loops
	int i = 0;
	//represents the number of elements
	int numE = 0;
	//for the last section of code
	//takes in a name of a player from the user
	string input = "";
	//represents the average rebounds of the player the user entered
	double rebound = 0;

	//opens centers_rebs_20_21.txt file
	inFile.open("centers_rebs_20_21.txt");
	if (!inFile.is_open()) {
		cout << "Could not open centers_rebs_20_21.txt file" << endl;
		return 1;
	}

	//initializes first element in name array
	inFile >> names[i];
	//loop to initialize name and average rebound arrays
	while (!inFile.fail()) {
		inFile >> avgRebs[i];
		++i;
		inFile >> names[i];
	}
	//number of elements in arrays
	numE = i;
	
	//calls print function to print out arrays
	print(names, avgRebs);
	//calls nameSort function to sort arrays using an insertion sort
	nameSort(names, avgRebs, numE);
	//prints out arrays after being sorted
	cout << "\n\nAfter being sorted:" << endl;
	print(names, avgRebs);

	//starts new lines
	cout << "\n\n";
	//loop for user to search for a player's average rebounds
	while (input != "-1") {
		//takes in a name from the user
		cout << "Enter a player's name (use _ instead of spaces):" << endl;
		cin >> input;
		//calls the search function to find the average rebounds using a binary search
		rebound = search(names, avgRebs, input, numE);
		//prints out result from search function
		if (rebound != -1) {
			cout << "Player " << input << " had " << rebound << " rebounds per game during the 2020-21 regular season.";
			cout << endl << endl;
		}
		else {
			cout << "Player cannot be found." << endl;
		}
	}

	return 0;
}